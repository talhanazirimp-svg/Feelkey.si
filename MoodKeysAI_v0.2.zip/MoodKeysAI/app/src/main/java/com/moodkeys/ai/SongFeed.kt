package com.moodkeys.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Live India "most played" chart from Apple's public RSS feed. Returns empty list if offline. */
object SongFeed {
    private const val FEED = "https://rss.applemarketingtools.com/api/v2/in/music/most-played/50/songs.json"

    fun fetch(): List<MoodMatcher.Song> = try {
        val c = URL(FEED).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        val body = c.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONObject(body).getJSONObject("feed").getJSONArray("results")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val t = o.getString("name")
            MoodMatcher.Song(t, o.getString("artistName"), MoodMatcher.moodOf(t))
        }
    } catch (e: Exception) { emptyList() }
}
