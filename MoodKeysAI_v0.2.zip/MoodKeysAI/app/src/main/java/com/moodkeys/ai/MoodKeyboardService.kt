package com.moodkeys.ai

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.URLEncoder

/** System-wide keyboard: English + Hindi + symbols, mood detection from the text before the cursor,
 *  and live Hindi/India trending song chips. Tap a chip to insert "Song – Artist + YouTube link". */
class MoodKeyboardService : InputMethodService() {
    private enum class Mode { EN, HI, SYM }
    private var mode = Mode.EN
    private var shift = false
    private var live: List<MoodMatcher.Song> = emptyList()
    private var lastFetch = 0L
    private var ready = false
    private lateinit var moodLabel: TextView
    private lateinit var strip: LinearLayout
    private lateinit var keys: LinearLayout

    private val BG = Color.rgb(24, 20, 43); private val KEY = Color.rgb(55, 45, 82)
    private val FN = Color.rgb(78, 66, 120); private val ACC = Color.rgb(124, 58, 237)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val hi = listOf("अआइईउऊएऐओऔ", "कखगघचछजझटठ", "डढतथदधनपफब", "भमयरलवशसहळ", "ािीुूेैोौंः्ृ")
    private val sym = listOf("1234567890", "@#₹_&-+()/", "!?\"':;,.*=")

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(3), dp(4), dp(3), dp(6)) }
        moodLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), dp(2), dp(8), dp(2)) }
        root.addView(moodLabel)
        strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })
        keys = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keys)
        ready = true; buildKeys(); refresh(); return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadLive(); if (ready) refresh()
    }

    private fun loadLive() {
        if (live.isNotEmpty() && System.currentTimeMillis() - lastFetch < 15 * 60_000) return
        Thread {
            val l = SongFeed.fetch()
            if (l.isNotEmpty()) { live = l; lastFetch = System.currentTimeMillis(); keys.post { refresh() } }
        }.start()
    }

    private fun refresh() {
        val before = currentInputConnection?.getTextBeforeCursor(300, 0)?.toString().orEmpty()
        val m = MoodMatcher.detect(before)
        moodLabel.text = "${MoodMatcher.emoji[m]} ${m.replaceFirstChar { it.uppercase() }} • ${if (live.isEmpty()) "offline snapshot" else "live trending"}"
        strip.removeAllViews()
        MoodMatcher.songsFor(m, live).forEach { s ->
            strip.addView(TextView(this).apply {
                text = "♫ ${s.title}"; setTextColor(Color.WHITE); textSize = 14f
                setPadding(dp(12), dp(7), dp(12), dp(7)); background = round(ACC, 20)
                setOnClickListener { insertSong(s) }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(3), dp(3), dp(5)) })
        }
    }

    private fun insertSong(s: MoodMatcher.Song) {
        val q = URLEncoder.encode("${s.title} ${s.artist}", "UTF-8")
        currentInputConnection?.commitText("🎵 ${s.title} – ${s.artist}\nhttps://www.youtube.com/results?search_query=$q", 1)
        refresh()
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun buildKeys() {
        keys.removeAllViews()
        val rows = when (mode) { Mode.EN -> en; Mode.HI -> hi; Mode.SYM -> sym }
        rows.forEachIndexed { i, r ->
            val line = row()
            if (mode == Mode.EN && i == 2) line.addView(key(if (shift) "⇩" else "⇧", 1.5f, FN) { shift = !shift; buildKeys() })
            r.forEach { c -> val s = c.toString(); line.addView(key(if (shift && mode == Mode.EN) s.uppercase() else s) { type(if (shift && mode == Mode.EN) s.uppercase() else s) }) }
            if (i == rows.lastIndex) line.addView(key("⌫", 1.5f, FN) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL); refresh() })
            keys.addView(line)
        }
        val b = row()
        b.addView(key(if (mode == Mode.SYM) "ABC" else "?123", 1.4f, FN) { mode = if (mode == Mode.SYM) Mode.EN else Mode.SYM; buildKeys() })
        b.addView(key(if (mode == Mode.HI) "EN" else "हिं", 1.4f, FN) { mode = if (mode == Mode.HI) Mode.EN else Mode.HI; shift = false; buildKeys() })
        b.addView(key("😂") { type("😂") }); b.addView(key("❤️") { type("❤️") }); b.addView(key("🔥") { type("🔥") })
        b.addView(key("space", 3f) { type(" ") })
        b.addView(key("।") { type("।") })
        b.addView(key("↵", 1.4f, ACC) { enter() })
        keys.addView(b)
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }

    private fun key(label: String, w: Float = 1f, color: Int = KEY, onTap: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
        background = round(color, 8); setOnClickListener { onTap() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), w).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift) { shift = false; buildKeys() }
        refresh()
    }

    private fun enter() {
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = (info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        if (noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) currentInputConnection?.commitText("\n", 1)
        else sendDefaultEditorAction(true)
        refresh()
    }
}
