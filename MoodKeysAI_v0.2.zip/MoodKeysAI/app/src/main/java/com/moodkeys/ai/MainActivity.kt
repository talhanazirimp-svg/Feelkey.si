package com.moodkeys.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val purple = Color.rgb(124, 58, 237)
    private lateinit var message: EditText
    private lateinit var suggestion: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(20, 17, 38))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        root.addView(label("MoodKeys AI 🎧", 28f, Color.WHITE, true))
        root.addView(label("Your emotions. Your sounds. Your chats.", 14f, Color.LTGRAY))
        root.addView(space(18))
        root.addView(label("Try a message", 18f, Color.WHITE, true))
        message = EditText(this).apply {
            hint = "e.g. Bro thinks he's the main character 💀"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(43, 35, 68))
            minLines = 2
        }
        root.addView(message, matchWrap())
        val find = Button(this).apply {
            text = "Find matching sound"
            setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { showSuggestion() }
        }
        root.addView(find, matchWrap())
        suggestion = label("Your sound suggestion will appear here.", 17f, Color.WHITE, true)
        suggestion.setPadding(16, 18, 16, 18)
        suggestion.setBackgroundColor(Color.rgb(43, 35, 68))
        root.addView(suggestion, matchWrap())
        val play = Button(this).apply {
            text = "▶ Preview demo sound"
            setOnClickListener {
                // Safe placeholder tone; replace with user-imported/licensed audio files.
                try { ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_ACK, 220) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "Demo tone unavailable", Toast.LENGTH_SHORT).show() }
            }
        }
        root.addView(play, matchWrap())
        root.addView(space(10))
        root.addView(label("Set up the keyboard", 18f, Color.WHITE, true))
        root.addView(label("Enable MoodKeys in Android Settings, then select it as your current keyboard. Works in every app: Hindi + English keys, mood detection and live Hindi/India trending song chips.", 14f, Color.LTGRAY))
        val setup = Button(this).apply {
            text = "Open keyboard settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        root.addView(setup, matchWrap())
        root.addView(label("Privacy-first prototype • Mood matching runs locally", 12f, Color.LTGRAY))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showSuggestion() {
        val result = MoodMatcher.suggest(message.text.toString())
        suggestion.text = "${result.emoji}  ${result.title}\nMood: ${result.mood}\n${result.hint}\n\nDemo suggestion only — add licensed audio to play the actual track."
    }
    private fun space(dp: Int) = TextView(this).apply { height = (dp * resources.displayMetrics.density).toInt() }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 }
}
