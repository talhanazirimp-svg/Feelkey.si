package com.moodkeys.ai

/** Offline mood detector (English, Hinglish, Hindi) + bundled Hindi trending snapshot used as fallback. */
object MoodMatcher {
    data class Song(val title: String, val artist: String, val mood: String)
    data class Suggestion(val mood: String, val title: String, val emoji: String, val hint: String)

    val emoji = mapOf("roast" to "💀", "sad" to "🥲", "romance" to "❤️", "hype" to "🔥", "funny" to "😂", "trending" to "🎬")

    private val words = linkedMapOf(
        "roast" to listOf("roast", "bro thinks", "clown", "idiot", "skill issue", "💀", "bakwas", "bewakoof", "pagal", "paagal", "ghamand", "nautanki", "बकवास", "बेवकूफ", "पागल", "घमंड", "नौटंकी"),
        "sad" to listOf("sad", "miss you", "cry", "lonely", "heartbroken", "😭", "🥲", "udaas", "dard", "yaad", "rona", "tanha", "bichad", "उदास", "दर्द", "याद", "रोना", "अकेला", "तन्हा"),
        "romance" to listOf("love", "pyaar", "pyar", "ishq", "dil", "jaan", "cute", "date", "❤", "😘", "😍", "mohabbat", "sanam", "प्यार", "इश्क", "दिल", "जान", "मोहब्बत", "सनम"),
        "hype" to listOf("won", "lets go", "let's go", "legend", "🔥", "hyped", "jeet", "mast", "party", "chak de", "जीत", "मस्त", "पार्टी", "धमाल"),
        "funny" to listOf("haha", "lol", "lmao", "funny", "joke", "😂", "🤣", "hasi", "mazak", "yaar", "bhai", "हंसी", "हँसी", "मज़ाक", "मजाक", "यार", "भाई")
    )

    // Snapshot of India charts (Apple Music India Aug 2026 / Billboard India Jul 2026). Used when offline.
    val snapshot = listOf(
        Song("Arz Kiya Hai", "Anuv Jain", "romance"), Song("Bairan", "Banjaare", "sad"),
        Song("Mann Mera", "Gajendra Verma", "sad"), Song("Gehra Hua", "Arijit Singh & Armaan Khan", "romance"),
        Song("Khat", "Navjot Ahuja", "romance"), Song("Aarzu", "Noor, Madhurxo, Asim Azhar", "romance"),
        Song("Barsaat", "Banjaare & Roni", "romance"), Song("Barbaad", "Jubin Nautiyal", "sad"),
        Song("Darmiyaan", "Rekha Bhardwaj", "sad"), Song("Kath Lagda", "Navaan Sandhu", "hype"),
        Song("Naal Nachna", "Shashwat Sachdev", "funny"), Song("Boom Shaka", "KR\$NA", "roast"),
        Song("Headliner", "Navaan Sandhu & Haakam", "roast"), Song("Raga of Revenge", "Anirudh", "roast"),
        Song("Winning Speech", "Karan Aujla", "hype"), Song("Jackpot", "Cheema Y & Gur Sidhu", "hype"),
        Song("Khuda Jaane", "KK & Shilpa Rao", "romance")
    )

    fun detect(text: String): String {
        val s = text.lowercase()
        return words.maxByOrNull { (_, w) -> w.count { s.contains(it) } }
            ?.takeIf { (_, w) -> w.any { s.contains(it) } }?.key ?: "trending"
    }

    fun moodOf(title: String) = snapshot.firstOrNull { title.contains(it.title, true) }?.mood ?: "trending"

    /** Mood-matched songs first, then the live chart. */
    fun songsFor(mood: String, live: List<Song>): List<Song> {
        val pool = if (live.isEmpty()) snapshot else live
        val matched = if (mood == "trending") emptyList() else (pool + snapshot).filter { it.mood == mood }
        return (matched + pool).distinctBy { it.title.lowercase() }.take(12)
    }

    fun suggest(text: String): Suggestion {
        val m = detect(text); val s = songsFor(m, emptyList()).first()
        return Suggestion(m.replaceFirstChar { it.uppercase() }, "${s.title} – ${s.artist}", emoji[m] ?: "🎬", "Trending Hindi pick")
    }
}
