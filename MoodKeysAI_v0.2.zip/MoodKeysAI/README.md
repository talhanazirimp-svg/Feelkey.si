# MoodKeys AI v0.2 — system-wide Hindi/English keyboard

- Works in every app once enabled (WhatsApp, Instagram, Notes…)
- English, हिन्दी and symbol layouts, emoji row, danda (।)
- Mood detection (English, Hinglish, Hindi) from the text before the cursor — works with whatever you've typed
- Live India trending chart (Apple Music RSS, refreshed every 15 min) with bundled offline snapshot as fallback
- Tap a song chip → inserts "Song – Artist" + YouTube search link into the chat

## Get an APK without Android Studio
1. Upload this folder to a new GitHub repo.
2. Actions tab → "Build APK" → Run workflow.
3. Download `MoodKeysAI-debug-apk`, install on your phone, then open the app → Open keyboard settings → enable MoodKeys → pick it as your keyboard.

## Or Android Studio
Open the folder, sync, run on your phone.

## Notes
- Untested on a device. The live feed is India's overall most-played chart (Hindi, Punjabi, others), not Hindi-only.
- Use licensed audio only; the keyboard shares links, not audio files.
